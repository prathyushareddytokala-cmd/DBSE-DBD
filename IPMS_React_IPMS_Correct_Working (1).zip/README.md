# IPMS — Insurance Policy Management System

React.js + Vite demo implementation based on the supplied project presentation and requirements.

## Included requirements

- Role-based portals: Admin, Agent, Customer
- Registration/login demo and role selection
- Customer management
- Policy creation, update/view and tracking
- Life, Health, Vehicle and Property policies
- Premium calculation/entry
- Premium payment monitoring
- Renewal due-date tracking and renewal action
- Renewal reminder notifications
- Online claim submission
- Claim document field and centralized document repository
- Claim status tracking
- Admin claim approval/rejection
- Centralized customer, policy, payment and claim records
- Policy sales, claim and revenue analytics
- Reports dashboard
- Notifications
- Responsive UI
- LocalStorage persistence for demo data

## Run in VS Code

1. Extract the ZIP.
2. Open the project folder in VS Code.
3. Open Terminal.
4. Run:

```bash
npm install
npm run dev
```

5. Open the localhost URL shown by Vite.

## Notes

This is a frontend/demo implementation. For production deployment, connect the forms and actions to the backend/API and MySQL or MongoDB, and replace the demo login with JWT authentication.

The supplied project presentation lists HTML5, CSS3, JavaScript, React.js, Bootstrap, Node.js/Java/Python backend options, MySQL/MongoDB, JWT, Git/GitHub, VS Code, Postman and XAMPP/MySQL Workbench as the technology choices. This package implements the React frontend and uses LocalStorage for a runnable demonstration.
