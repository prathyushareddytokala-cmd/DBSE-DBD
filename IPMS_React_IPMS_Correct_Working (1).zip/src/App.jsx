import React, { useEffect, useMemo, useState } from "react";

const initialData = {
  policies: [
    { id:"P-1024", customer:"Pooja Mehta", type:"Property", premium:18500, status:"Active", renewal:"2027-08-15", agent:"Rahul Verma" },
    { id:"P-1023", customer:"Arjun Khan", type:"Life", premium:24000, status:"Active", renewal:"2027-05-20", agent:"Priya Shah" },
    { id:"P-1022", customer:"Sneha Verma", type:"Health", premium:12000, status:"Active", renewal:"2027-03-12", agent:"Rahul Verma" },
    { id:"P-1021", customer:"Avi Sharma", type:"Property", premium:16500, status:"Renewal Due", renewal:"2026-11-05", agent:"Priya Shah" },
    { id:"P-1020", customer:"Karthik Menon", type:"Vehicle", premium:9800, status:"Active", renewal:"2027-01-28", agent:"Rahul Verma" }
  ],
  customers: [
    { id:"CUST-001", name:"Pooja Mehta", email:"pooja@example.com", phone:"+91 98765 43210", policies:1, joined:"2026-08-12" },
    { id:"CUST-002", name:"Arjun Khan", email:"arjun@example.com", phone:"+91 98765 11122", policies:1, joined:"2026-07-20" },
    { id:"CUST-003", name:"Sneha Verma", email:"sneha@example.com", phone:"+91 98765 33344", policies:1, joined:"2026-06-11" },
    { id:"CUST-004", name:"Avi Sharma", email:"avi@example.com", phone:"+91 98765 55566", policies:1, joined:"2026-05-19" },
    { id:"CUST-005", name:"Karthik Menon", email:"karthik@example.com", phone:"+91 98765 77788", policies:1, joined:"2026-09-02" }
  ],
  claims: [
    { id:"CLM-5012", customer:"Sneha Verma", policy:"P-1022", type:"Health", amount:45000, status:"Submitted", date:"2026-10-03" },
    { id:"CLM-5001", customer:"Arjun Khan", policy:"P-1023", type:"Life", amount:120000, status:"Approved", date:"2026-09-30" },
    { id:"CLM-5007", customer:"Pooja Mehta", policy:"P-1024", type:"Property", amount:35000, status:"Under Review", date:"2026-09-27" }
  ],
  payments: [
    { id:"PAY-9001", customer:"Pooja Mehta", policy:"P-1024", amount:18500, method:"UPI", status:"Paid", date:"2026-09-15" },
    { id:"PAY-9002", customer:"Arjun Khan", policy:"P-1023", amount:24000, method:"Card", status:"Paid", date:"2026-09-10" },
    { id:"PAY-9003", customer:"Avi Sharma", policy:"P-1021", amount:16500, method:"Net Banking", status:"Pending", date:"2026-09-05" }
  ],
  documents: [
    { id:"DOC-001", name:"Pooja Mehta — Property Policy", type:"Policy Document", date:"2026-08-15" },
    { id:"DOC-002", name:"Arjun Khan — Life Policy", type:"Policy Document", date:"2026-07-20" },
    { id:"DOC-003", name:"Sneha Verma — Health Claim", type:"Claim Document", date:"2026-10-03" }
  ]
};

const activitySeed = [
  ["New policy P-1024 issued for Pooja Mehta","Property Insurance","2 hours ago"],
  ["Claim CLM-5012 submitted by Sneha Verma","Health Insurance","4 hours ago"],
  ["Policy P-1021 renewed for Avi Sharma","Property Insurance","1 day ago"],
  ["New customer Karthik Menon registered","Customer","2 days ago"],
  ["Claim CLM-5001 approved for Arjun Khan","Life Insurance","3 days ago"]
];

const nav = {
  Admin:["Dashboard","Policies","Customers","Claims","Payments","Documents","Renewals","Reports","Notifications"],
  Agent:["Dashboard","Customers","Policies","Claims","Renewals","Notifications"],
  Customer:["Dashboard","My Policies","Buy Policy","Payments","Claims","Documents","Renewals","Notifications"]
};

function money(n){ return "₹" + Number(n).toLocaleString("en-IN"); }
function loadData(){ try{return JSON.parse(localStorage.getItem("ipmsData")) || initialData}catch{return initialData} }
function saveData(d){localStorage.setItem("ipmsData",JSON.stringify(d));}

function App(){
  const [role,setRole]=useState(localStorage.getItem("ipmsRole")||"Admin");
  const [user,setUser]=useState(localStorage.getItem("ipmsUser")||"Admin User");
  const [data,setData]=useState(loadData);
  const [page,setPage]=useState("Dashboard");
  const [query,setQuery]=useState("");
  const [modal,setModal]=useState(null);
  const [toast,setToast]=useState("");
  const [selected,setSelected]=useState(null);

  useEffect(()=>{saveData(data)},[data]);
  useEffect(()=>{if(toast){const t=setTimeout(()=>setToast(""),2800);return()=>clearTimeout(t)}},[toast]);

  const changeRole=(r)=>{setRole(r);localStorage.setItem("ipmsRole",r);localStorage.setItem("ipmsUser",r==="Customer"?"Pooja Mehta":r==="Agent"?"Rahul Verma":"Admin User");setPage("Dashboard");setQuery("")};
  const logout=()=>{localStorage.removeItem("ipmsRole");localStorage.removeItem("ipmsUser");setRole("Admin");setUser("Admin User");setPage("Dashboard")};

  const update=(key,items)=>setData(d=>({...d,[key]:items}));
  const notify=(m)=>setToast(m);

  const filteredPolicies=data.policies.filter(x=>Object.values(x).join(" ").toLowerCase().includes(query.toLowerCase()));
  const filteredCustomers=data.customers.filter(x=>Object.values(x).join(" ").toLowerCase().includes(query.toLowerCase()));
  const filteredClaims=data.claims.filter(x=>Object.values(x).join(" ").toLowerCase().includes(query.toLowerCase()));

  const customerName=role==="Customer" ? user : null;
  const visiblePolicies=role==="Customer"?data.policies.filter(x=>x.customer===customerName):filteredPolicies;
  const visibleClaims=role==="Customer"?data.claims.filter(x=>x.customer===customerName):filteredClaims;
  const visiblePayments=role==="Customer"?data.payments.filter(x=>x.customer===customerName):data.payments;

  const stats={
    policies:data.policies.length,
    customers:data.customers.length,
    claims:data.claims.length,
    revenue:data.payments.filter(x=>x.status==="Paid").reduce((a,x)=>a+Number(x.amount),0)
  };

  const addPolicy=(form)=>{
    const id="P-"+(1025+data.policies.length);
    update("policies",[...data.policies,{...form,id,premium:Number(form.premium),status:"Active"}]);
    notify(`Policy ${id} created successfully`);
    setModal(null);
  };
  const addCustomer=(form)=>{
    const id="CUST-"+String(data.customers.length+1).padStart(3,"0");
    update("customers",[...data.customers,{...form,id,policies:0,joined:new Date().toISOString().slice(0,10)}]);
    notify("Customer registered successfully");setModal(null);
  };
  const addClaim=(form)=>{
    const id="CLM-"+(5013+data.claims.length);
    update("claims",[...data.claims,{...form,id,amount:Number(form.amount),date:new Date().toISOString().slice(0,10),status:"Submitted"}]);
    notify(`Claim ${id} submitted`);setModal(null);
  };

  if(page==="Login") return <Login onLogin={(r,n)=>{changeRole(r);setUser(n)}}/>;

  return <div className="app">
    <Sidebar role={role} page={page} setPage={setPage} />
    <div className="main">
      <header className="topbar">
        <div className="mobile-brand"><b>IPMS</b></div>
        <div className="search"><span>⌕</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search policies, customers, claims..." /></div>
        <div className="top-actions">
          <button className="icon-btn" onClick={()=>setPage("Notifications")}>🔔<i>3</i></button>
          <div className="user-menu"><div className="avatar">{user[0]}</div><div><b>{user}</b><small>{role}</small></div></div>
          <button className="logout" onClick={logout}>Logout</button>
        </div>
      </header>

      <div className="content">
        <PageHeader title={page} subtitle={subtitle(page,role)} />

        {page==="Dashboard" && <Dashboard role={role} stats={stats} data={data} setPage={setPage} visiblePolicies={visiblePolicies} visibleClaims={visibleClaims} />}
        {page==="Policies" && <Policies data={visiblePolicies} role={role} onAdd={()=>setModal("policy")} onView={(p)=>setSelected({type:"policy",item:p})} onRenew={(p)=>{update("policies",data.policies.map(x=>x.id===p.id?{...x,status:"Active",renewal:"2027-10-03"}:x));notify(`${p.id} renewed successfully`)}} />}
        {page==="My Policies" && <Policies data={visiblePolicies} role="Customer" onAdd={()=>setPage("Buy Policy")} onView={(p)=>setSelected({type:"policy",item:p})} onRenew={(p)=>{update("policies",data.policies.map(x=>x.id===p.id?{...x,status:"Active",renewal:"2027-10-03"}:x));notify(`${p.id} renewed successfully`)}} />}
        {page==="Buy Policy" && <BuyPolicy onBuy={(form)=>{addPolicy({...form,customer:user,agent:"Rahul Verma"})}} />}
        {page==="Customers" && <Customers data={filteredCustomers} onAdd={()=>setModal("customer")} onSelect={(c)=>setSelected({type:"customer",item:c})} />}
        {page==="Claims" && <Claims data={visibleClaims} role={role} onAdd={()=>setModal("claim")} onStatus={(id,status)=>{update("claims",data.claims.map(x=>x.id===id?{...x,status}:x));notify(`Claim ${id} marked ${status}`)}} />}
        {page==="Payments" && <Payments data={visiblePayments} onPay={(id)=>{update("payments",data.payments.map(x=>x.id===id?{...x,status:"Paid"}:x));notify(`Payment ${id} completed`)}} />}
        {page==="Documents" && <Documents data={data.documents} onAdd={()=>setModal("document")} onDownload={(d)=>{const blob=new Blob([`IPMS Document\n${d.name}\nType: ${d.type}\nDate: ${d.date}`],{type:"text/plain"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=(d.name||"document").replace(/[^a-z0-9]+/gi,"_")+".txt";a.click();notify("Document download started")}} />}
        {page==="Renewals" && <Renewals policies={visiblePolicies} onRenew={(p)=>{update("policies",data.policies.map(x=>x.id===p.id?{...x,status:"Active",renewal:"2027-10-03"}:x));notify(`${p.id} renewed successfully`)}} notify={notify}/>}
        {page==="Reports" && <Reports data={data} stats={stats} />}
        {page==="Notifications" && <Notifications role={role} />}
      </div>
    </div>
    {toast && <div className="toast">✓ {toast}</div>}
    {modal==="policy" && <Modal title="Create New Policy" close={()=>setModal(null)}><PolicyForm customers={data.customers} onSubmit={addPolicy}/></Modal>}
    {modal==="customer" && <Modal title="Register New Customer" close={()=>setModal(null)}><CustomerForm onSubmit={addCustomer}/></Modal>}
    {modal==="claim" && <Modal title="Submit Claim" close={()=>setModal(null)}><ClaimForm policies={data.policies} customer={role==="Customer"?user:""} onSubmit={addClaim}/></Modal>}
    {modal==="document" && <Modal title="Upload Document" close={()=>setModal(null)}><DocumentForm onSave={(d)=>{const id="DOC-"+String(data.documents.length+1).padStart(3,"0");update("documents",[...data.documents,{...d,id,date:new Date().toISOString().slice(0,10)}]);notify("Document uploaded");setModal(null)}}/></Modal>}
    {selected && <Modal title={selected.type==="policy"?"Policy Details":"Customer Profile"} close={()=>setSelected(null)}>{selected.type==="policy"?<PolicyDetails item={selected.item}/>:<CustomerDetails item={selected.item}/>}</Modal>}
  </div>
}

function subtitle(p,r){
  const s={Dashboard:"Overview of policies, customers, claims and revenue across IPMS.",Policies:"Create, update and track insurance policies.",Customers:"Centralized customer registration and management.",Claims:"Submit, review and track claims.",Payments:"Premium payments and transaction monitoring.",Documents:"Policy and claim document repository.",Renewals:"Due dates, renewal tracking and reminders.",Reports:"Policy sales, claim trends and revenue analytics.",Notifications:"Renewal, claim and system notifications.","My Policies":"Your active and past insurance policies.","Buy Policy":"Choose a policy and calculate the applicable premium."};
  return s[p]||`${r} workspace`;
}

function Sidebar({role,page,setPage}){
 return <aside className="sidebar">
   <div className="brand"><div className="brand-icon">IP</div><div><strong>IPMS</strong><small>Insurance Management</small></div></div>
   <div className="role-pill">● {role} Portal</div>
   <nav>{nav[role].map(n=><button key={n} className={page===n?"selected":""} onClick={()=>setPage(n)}><span>{icons[n]||"•"}</span>{n}</button>)}</nav>
   <div className="sidebar-foot"><div className="secure">🔒 Secure Role-Based Access</div><small>IPMS v1.0</small></div>
 </aside>
}
const icons={Dashboard:"⌂",Policies:"▣","My Policies":"▣","Buy Policy":"＋",Customers:"♙",Claims:"✓",Payments:"₹",Documents:"▤",Renewals:"↻",Reports:"▥",Notifications:"◉"};

function PageHeader({title,subtitle}){return <div className="page-head"><div><h1>{title}</h1><p>{subtitle}</p></div><span className="date-chip">03 Oct 2026</span></div>}

function Dashboard({role,stats,data,setPage,visiblePolicies,visibleClaims}){
 const recent=activitySeed;
 return <div>
   <div className="stat-grid">
    <Stat icon="▣" label="Total Policies" value={stats.policies} cls="blue"/>
    <Stat icon="♙" label="Total Customers" value={stats.customers} cls="green"/>
    <Stat icon="✓" label="Total Claims" value={stats.claims} cls="orange"/>
    <Stat icon="₹" label="Total Revenue" value={money(stats.revenue)} cls="purple"/>
   </div>
   <div className="dashboard-grid">
     <section className="panel sales-panel"><PanelTitle title="Policy Sales Overview" sub="Policies sold per month"/><SalesChart/></section>
     <section className="panel"><PanelTitle title="Policy Type Distribution" sub={`${data.policies.length} Total Policies`}/><Donut data={data.policies}/></section>
   </div>
   <div className="dashboard-grid lower">
     <section className="panel"><PanelTitle title="Recent Activities" action="View All" onAction={()=>setPage("Notifications")}/><ActivityList items={recent}/></section>
     <section className="panel"><PanelTitle title={role==="Customer"?"My Policies":"Renewals Due"} sub="Action required"/>
       {(role==="Customer"?visiblePolicies:data.policies.filter(x=>x.status==="Renewal Due")).slice(0,4).map(p=><div className="mini-row" key={p.id}><div><b>{p.id}</b><span>{p.customer} · {p.type}</span></div><strong>{p.renewal}</strong></div>)}
     </section>
   </div>
 </div>
}
function Stat({icon,label,value,cls}){return <div className="stat"><div className={`stat-icon ${cls}`}>{icon}</div><div><span>{label}</span><b>{value}</b><small>Updated today</small></div></div>}
function PanelTitle({title,sub,action,onAction}){return <div className="panel-title"><div><h2>{title}</h2>{sub&&<p>{sub}</p>}</div>{action&&<button onClick={onAction}>{action} →</button>}</div>}

function SalesChart(){
 const vals=[65,85,100,75,120,105,145,130,155,125,165,180], months=["Nov","Dec","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct"];
 return <div className="sales-chart"><div className="ylabels"><span>180</span><span>135</span><span>90</span><span>45</span><span>0</span></div><div className="chart-body"><div className="chart-lines">{[1,2,3,4,5].map(i=><i key={i}/>)}</div><div className="bars">{vals.map((v,i)=><div className="bar-col" key={months[i]}><div className="bar" style={{height:`${v/180*100}%`}}/><small>{months[i]}</small></div>)}</div></div></div>
}
function Donut({data}){const counts=["Life","Health","Vehicle","Property"].map(t=>data.filter(p=>p.type===t).length);const total=Math.max(data.length,1);return <div className="donut-wrap"><div className="donut" style={{background:`conic-gradient(#2563eb 0 ${counts[0]/total*360}deg,#12b76a ${counts[0]/total*360}deg ${(counts[0]+counts[1])/total*360}deg,#f79009 ${(counts[0]+counts[1])/total*360}deg ${(counts[0]+counts[1]+counts[2])/total*360}deg,#7f56d9 ${(counts[0]+counts[1]+counts[2])/total*360}deg 360deg)`}}><div><b>{data.length}</b><small>Total Policies</small></div></div><div className="legend">{["Life","Health","Vehicle","Property"].map((x,i)=><div key={x}><i className={`d${i}`}/><span>{x}</span><b>{Math.round(counts[i]/total*100)}%</b></div>)}</div></div>}
function ActivityList({items}){return <div className="activities">{items.map((x,i)=><div className="activity" key={i}><div className="activity-dot">{["▣","✓","↻","♙","✓"][i]}</div><div><b>{x[0]}</b><span>{x[1]}</span></div><time>{x[2]}</time></div>)}</div>}

function Policies({data,role,onAdd,onView,onRenew}){return <TableCard title={role==="Customer"?"My Policies":"Policy Management"} add={role!=="Customer"?"＋ Create Policy":null} onAdd={onAdd}><table><thead><tr><th>Policy ID</th><th>Customer</th><th>Type</th><th>Premium</th><th>Status</th><th>Renewal</th><th>Action</th></tr></thead><tbody>{data.map(p=><tr key={p.id}><td><b>{p.id}</b></td><td>{p.customer}</td><td><Badge type={p.type}/></td><td>{money(p.premium)}</td><td><Status text={p.status}/></td><td>{p.renewal}</td><td>{p.status==="Renewal Due"?<><button className="link-btn" onClick={()=>onRenew(p)}>Renew</button><button className="link-btn" onClick={()=>onView(p)}>View</button></>:<button className="link-btn" onClick={()=>onView(p)}>View</button>}</td></tr>)}</tbody></table></TableCard>}
function Customers({data,onAdd,onSelect}){return <TableCard title="Customer Management" add="＋ Register Customer" onAdd={onAdd}><table><thead><tr><th>Customer</th><th>Contact</th><th>Policies</th><th>Joined</th><th>Action</th></tr></thead><tbody>{data.map(c=><tr key={c.id}><td><div className="person"><div>{c.name[0]}</div><b>{c.name}</b></div></td><td>{c.email}<br/><span className="muted">{c.phone}</span></td><td>{c.policies}</td><td>{c.joined}</td><td><button className="link-btn" onClick={()=>onSelect(c)}>View Profile</button></td></tr>)}</tbody></table></TableCard>}
function Claims({data,role,onAdd,onStatus}){return <TableCard title="Claims Processing" add={role==="Customer"?"＋ Submit Claim":null} onAdd={onAdd}><table><thead><tr><th>Claim ID</th><th>Customer</th><th>Policy</th><th>Amount</th><th>Status</th><th>Date</th>{role==="Admin"&&<th>Decision</th>}</tr></thead><tbody>{data.map(c=><tr key={c.id}><td><b>{c.id}</b></td><td>{c.customer}</td><td>{c.policy}</td><td>{money(c.amount)}</td><td><Status text={c.status}/></td><td>{c.date}</td>{role==="Admin"&&<td>{c.status==="Submitted"||c.status==="Under Review"?<><button className="approve" onClick={()=>onStatus(c.id,"Approved")}>Approve</button><button className="reject" onClick={()=>onStatus(c.id,"Rejected")}>Reject</button></>: "—"}</td>}</tr>)}</tbody></table></TableCard>}
function Payments({data,onPay}){return <TableCard title="Premium Payments"><table><thead><tr><th>Payment ID</th><th>Customer</th><th>Policy</th><th>Amount</th><th>Method</th><th>Status</th><th>Date</th><th>Action</th></tr></thead><tbody>{data.map(p=><tr key={p.id}><td><b>{p.id}</b></td><td>{p.customer}</td><td>{p.policy}</td><td>{money(p.amount)}</td><td>{p.method}</td><td><Status text={p.status}/></td><td>{p.date}</td><td>{p.status==="Pending"?<button className="primary" onClick={()=>onPay(p.id)}>Pay Premium</button>:<span className="muted">Completed</span>}</td></tr>)}</tbody></table></TableCard>}
function Documents({data,onAdd,onDownload}){return <TableCard title="Centralized Documents" add="＋ Upload Document" onAdd={onAdd}><div className="doc-grid">{data.map(d=><div className="doc-card" key={d.id}><div className="doc-icon">PDF</div><div><b>{d.name}</b><span>{d.type}</span><small>{d.date}</small></div><button onClick={()=>onDownload(d)}>Download</button></div>)}</div></TableCard>}
function Renewals({policies,onRenew,notify}){return <TableCard title="Renewal Monitoring"><div className="renewal-grid">{policies.map(p=><div className="renewal-card" key={p.id}><div className="renewal-top"><Badge type={p.type}/><Status text={p.status}/></div><h3>{p.id}</h3><p>{p.customer}</p><div className="renewal-date">Renewal date <b>{p.renewal}</b></div><div className="progress"><i style={{width:p.status==="Renewal Due"?"88%":"45%"}}/></div><button onClick={()=>p.status==="Renewal Due"?onRenew(p):notify(`Renewal reminder set for ${p.id}`)}>{p.status==="Renewal Due"?"Renew Now":"Set Reminder"}</button></div>)}</div></TableCard>}
function Reports({data,stats}){const claimTotal=data.claims.reduce((a,x)=>a+Number(x.amount),0);return <div className="report-grid"><div className="report-card big"><h3>Management Analytics</h3><p>Actionable insights for policy sales, claims and revenue.</p><div className="report-bars">{[["Policy Sales",78],["Premium Revenue",91],["Claims Resolved",66],["Renewals",72]].map(x=><div key={x[0]}><span>{x[0]}</span><i><b style={{width:x[1]+"%"}}/></i><strong>{x[1]}%</strong></div>)}</div></div><div className="report-card"><span>Total Revenue</span><b>{money(stats.revenue)}</b><small>Paid premium transactions</small></div><div className="report-card"><span>Claim Exposure</span><b>{money(claimTotal)}</b><small>Total submitted claim value</small></div><div className="report-card"><span>Active Policies</span><b>{data.policies.filter(x=>x.status==="Active").length}</b><small>Across all insurance types</small></div><div className="report-card"><span>Renewal Due</span><b>{data.policies.filter(x=>x.status==="Renewal Due").length}</b><small>Policies requiring action</small></div></div>}
function Notifications(){return <div className="notification-list">{[["Renewal Reminder","Policy P-1021 for Avi Sharma is due for renewal on 05 Nov 2026.","Today"],["Claim Update","Claim CLM-5012 submitted by Sneha Verma is under review.","4 hours ago"],["Payment Reminder","Premium payment for P-1021 is pending.","Yesterday"],["System","New customer Karthik Menon registered successfully.","2 days ago"]].map(x=><div className="notification" key={x[0]+x[2]}><div>🔔</div><section><b>{x[0]}</b><p>{x[1]}</p><small>{x[2]}</small></section></div>)}</div>}
function BuyPolicy({onBuy}){return <div className="buy-layout"><div className="buy-info"><span className="eyebrow">DIGITAL POLICY ISSUANCE</span><h2>Choose protection that fits your needs.</h2><p>Complete the details and IPMS will calculate an applicable premium estimate.</p><ul><li>✓ Instant premium calculation</li><li>✓ Digital policy records</li><li>✓ Renewal reminders</li><li>✓ Online claim tracking</li></ul></div><div className="form-card"><PolicyForm customers={[]} customerOnly onSubmit={onBuy}/></div></div>}

function TableCard({title,add,onAdd,children}){return <section className="panel table-panel"><div className="panel-title"><div><h2>{title}</h2><p>Manage and monitor records securely.</p></div>{add&&<button className="primary" onClick={onAdd}>{add}</button>}</div><div className="table-wrap">{children}</div></section>}
function Badge({type}){return <span className={`badge ${type.toLowerCase()}`}>{type}</span>}
function Status({text}){return <span className={`status ${text.toLowerCase().replaceAll(" ","-")}`}>{text}</span>}
function Modal({title,close,children}){return <div className="overlay" onMouseDown={e=>e.target===e.currentTarget&&close()}><div className="modal"><div className="modal-head"><h2>{title}</h2><button onClick={close}>×</button></div>{children}</div></div>}


function CustomerDetails({item}){return <div className="details"><p><b>Customer ID:</b> {item.id}</p><p><b>Name:</b> {item.name}</p><p><b>Email:</b> {item.email}</p><p><b>Phone:</b> {item.phone}</p><p><b>Policies:</b> {item.policies}</p><p><b>Joined:</b> {item.joined}</p></div>}
function PolicyDetails({item}){return <div className="details"><p><b>Policy ID:</b> {item.id}</p><p><b>Customer:</b> {item.customer}</p><p><b>Type:</b> {item.type}</p><p><b>Premium:</b> {money(item.premium)}</p><p><b>Status:</b> {item.status}</p><p><b>Renewal:</b> {item.renewal}</p><p><b>Agent:</b> {item.agent||"Rahul Verma"}</p></div>}
function DocumentForm({onSave}){const [name,setName]=useState("");const [type,setType]=useState("Policy Document");return <form onSubmit={e=>{e.preventDefault();onSave({name,type})}}><label>Document Name<input required value={name} onChange={e=>setName(e.target.value)}/></label><label>Document Type<select value={type} onChange={e=>setType(e.target.value)}><option>Policy Document</option><option>Claim Document</option></select></label><label>Select File<input type="file"/></label><button className="primary full">Upload Document</button></form>}
function PolicyForm({customers,customerOnly,onSubmit}){const [f,setF]=useState({customer:customers[0]?.name||"",type:"Health",premium:"",renewal:"2027-10-03",agent:"Rahul Verma"});const calc={Life:24000,Health:12000,Vehicle:9800,Property:18500};const change=e=>setF({...f,[e.target.name]:e.target.value});return <form onSubmit={e=>{e.preventDefault();onSubmit({...f,premium:f.premium||calc[f.type]})}}><label>Customer<select name="customer" value={f.customer} onChange={change} disabled={customerOnly}>{customers.length?customers.map(c=><option key={c.id}>{c.name}</option>):<option>Current Customer</option>}</select></label><label>Policy Type<select name="type" value={f.type} onChange={change}>{["Life","Health","Vehicle","Property"].map(x=><option key={x}>{x}</option>)}</select></label><label>Premium (₹)<input name="premium" type="number" value={f.premium||calc[f.type]} onChange={change}/></label><label>Renewal Date<input name="renewal" type="date" value={f.renewal} onChange={change}/></label><button className="primary full" type="submit">Calculate & Create Policy</button></form>}
function CustomerForm({onSubmit}){const [f,setF]=useState({name:"",email:"",phone:""});return <form onSubmit={e=>{e.preventDefault();onSubmit(f)}}><label>Full Name<input required value={f.name} onChange={e=>setF({...f,name:e.target.value})}/></label><label>Email<input required type="email" value={f.email} onChange={e=>setF({...f,email:e.target.value})}/></label><label>Phone<input required value={f.phone} onChange={e=>setF({...f,phone:e.target.value})}/></label><button className="primary full">Register Customer</button></form>}
function ClaimForm({policies,customer,onSubmit}){const mine=customer?policies.filter(x=>x.customer===customer):policies;const [f,setF]=useState({customer:customer||mine[0]?.customer||"",policy:mine[0]?.id||"",type:mine[0]?.type||"Health",amount:""});return <form onSubmit={e=>{e.preventDefault();onSubmit(f)}}><label>Customer<input required value={f.customer} disabled={!!customer} onChange={e=>setF({...f,customer:e.target.value})}/></label><label>Policy<select value={f.policy} onChange={e=>{const p=policies.find(x=>x.id===e.target.value);setF({...f,policy:e.target.value,type:p?.type||f.type})}}>{mine.map(p=><option key={p.id}>{p.id}</option>)}</select></label><label>Claim Type<input value={f.type} readOnly/></label><label>Claim Amount (₹)<input required type="number" value={f.amount} onChange={e=>setF({...f,amount:e.target.value})}/></label><label>Supporting Document<input type="file" /></label><button className="primary full">Submit Claim</button></form>}

function Login({onLogin}){const [r,setR]=useState("Admin"),[n,setN]=useState("Admin User");return <div className="login-page"><div className="login-card"><div className="login-logo">IP</div><h1>Insurance Policy Management System</h1><p>Secure portal for policies, premiums, renewals and claims.</p><div className="role-switch">{["Admin","Agent","Customer"].map(x=><button className={r===x?"active":""} onClick={()=>{setR(x);setN(x==="Customer"?"Pooja Mehta":x==="Agent"?"Rahul Verma":"Admin User")}} key={x}>{x}</button>)}</div><label>Name<input value={n} onChange={e=>setN(e.target.value)}/></label><label>Email<input placeholder="name@example.com"/></label><label>Password<input type="password" placeholder="••••••••"/></label><button className="primary full" onClick={()=>onLogin(r,n)}>Login to {r} Portal</button><small className="demo">Demo login — choose a role above. Backend/JWT can be connected later.</small></div></div>}

export default App;